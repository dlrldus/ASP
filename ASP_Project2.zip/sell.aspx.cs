﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class sell : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}